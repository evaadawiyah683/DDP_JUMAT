from gempa import *

Gempa1 = Gempa('Banten',1.2)
Gempa1.dampak()

Gempa2 = Gempa('palu',6.1)
Gempa2.dampak()

Gempa3 = Gempa('cianjur',5.6)
Gempa3.dampak()

Gempa4 = Gempa('jayapura',3.3)
Gempa4.dampak()

Gempa5 = Gempa('Garot',4.0)
Gempa5.dampak()

